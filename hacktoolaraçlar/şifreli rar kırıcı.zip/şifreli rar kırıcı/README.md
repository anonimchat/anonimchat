# pyrarcr

A password cracker for RAR,ZIP and 7z files written in Python 3.

## Usage

python3 pyrarcr.py [rar file]

## Contribution and License Agreement

If you contribute code to this project, you are implicitly allowing your code
to be distributed under the MIT license. You are also implicitly verifying that
all code is your original work.

## License

See LICENSE.
